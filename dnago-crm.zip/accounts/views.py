from django.shortcuts import render, redirect
from django.forms import inlineformset_factory
from .models import *
from .forms import orderForm, CreateUserForm
from django.contrib.auth.forms import UserCreationForm
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required


# Create your views here.


def registerpage(request):

    form = CreateUserForm()
    if request.method == 'POST':
        form =CreateUserForm(request.POST)
        if form.is_valid():
            form.save()
            user = form.cleaned_data.get('username')
            messages.success(request, 'Account Created Succesfuly for ' + user)
            return redirect('login')

    context = {
        'form':form
    }

    return render(request, 'accounts/register.html',context)

def loginpage(request):
	if request.user.is_authenticated:
		return redirect('index')
	else:
		if request.method == 'POST':
			username = request.POST.get('username')
			password =request.POST.get('password')

			user = authenticate(request, username=username, password=password)

			if user is not None:
				login(request, user)
				return redirect('index')
			else:
				messages.info(request, 'Username OR password is incorrect')

		context = {}
	return render(request, 'accounts/login.html', context)

def logoutUser(request):
    logout(request)
    return redirect('login')


@login_required(login_url='login')
def index(request): 
 

    orders = order.objects.all()
    customers = Customer.objects.all()

    total_orders = orders.count()
    total_customers = customers.count()
    delivered = orders.filter(status = 'delivered').count()
    pending = orders.filter(status = 'pending').count()

    
    

    context = {
        
        'orders':orders,
        'customers':customers,
        'delivered':delivered,
        'pending':pending,
        'total_orders':total_orders,
        'total_customers':total_customers
    }


    return render(request,'accounts/home.html', context)

@login_required(login_url='login')
def userpage(request):
    return render(request, 'accounts/user.html')


@login_required(login_url='login')
def products(request):
    
    products = product.objects.all()

    return render(request,'accounts/products.html', {'products':products})

@login_required(login_url='login')
def customer(request,pk_test):
    customer = Customer.objects.get(id = pk_test)

    orders =customer.order_set.all()
    order_count = orders.count()

    context = {
        'customer':customer,
         'orders':orders,
         'order_count':order_count
    }


    return render(request,'accounts/customer.html', context)


@login_required(login_url='login')
def createOrder(request, pk):
    OrderFormSet = inlineformset_factory(Customer, order, fields=('product', 'status'), extra=5 )
    customer = Customer.objects.get(id=pk)
    formset = OrderFormSet(queryset=order.objects.none(),instance=customer)
	#form = OrderForm(initial={'customer':customer})
    if request.method == 'POST':
		#print('Printing POST:', request.POST)
		#form = OrderForm(request.POST)
        formset = OrderFormSet(request.POST, instance=customer)
        if formset.is_valid():
            formset.save()
            return redirect('/')

    context = {'form':formset}
    return render(request, 'accounts/order_form.html', context)
	
	

	


@login_required(login_url='login')
def updateOrder(request, pk):
    
	Order = order.objects.get(id=pk)
	form = orderForm(instance=Order)

	if request.method == 'POST':
		form = orderForm(request.POST, instance=Order)
		if form.is_valid():
			form.save()
			return redirect('/')

	context = {'form':form}
	return render(request, 'accounts/order_form.html', context)


@login_required(login_url='login')
def deleteOrder(request,pk):
    Order = order.objects.get(id=pk)
    if request.method == 'POST':
        Order.delete()
        return redirect('/')
    context = {
        'item':Order

    }
    return render (request,'accounts/delete.html', context)



        
    

