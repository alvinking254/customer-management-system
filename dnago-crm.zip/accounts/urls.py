
from django.urls import path
from .import views

urlpatterns = [

    path('register/', views.registerpage,name = 'register'),

    path('login/', views.loginpage, name ='login'),

    path('logout/', views.logoutUser, name="logout"),

    path('',views.index,name='index'), 

    path('userpage',views.userpage,name='viewspage'),

    path('customer/<str:pk_test>/',views.customer, name='customer'),
    
    path('products/',views.products, name='products'),

   path('create_order/<str:pk>/',views.createOrder ,name = 'create_order'),

   path('update_order/<str:pk>/', views.updateOrder,name='update_order'),

   path('delete_order/<str:pk>/', views.deleteOrder,name='delete_order')
]
